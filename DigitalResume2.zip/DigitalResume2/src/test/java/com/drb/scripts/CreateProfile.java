package com.drb.scripts;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.drb.pages.AdminObjects;
import com.drb.pages.CreateProfileObjects;
import com.drb.pages.LoginPage;
import com.drb.pages.MyProfile;
import com.drb.utilities.ExcelUtility;

@Listeners(CustomListeners.class)
public class CreateProfile extends TestBase {
	public WebDriver driver;

	//public CreateProfile(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		//this.driver=driver2;
	//}
@BeforeTest
	public void browserInvoke() throws IOException {
		driver=initinalizeDriver();

	}

@Test(priority=1)
	public void Login() throws IOException {
		LoginPage login=new LoginPage(driver);
		login.clickSignup().click();
		
		String username=ExcelUtility.getStringCellData(0, 1);
		String password=ExcelUtility.getStringCellData(1, 1);
		login.getUsername().sendKeys(username);
		login.getPassword().sendKeys(password);
		login.getCheckbox().click();
		login.getLoginButton().click();

	}

@Test(priority=2) 
//testcase to check all the data provided while sign up is present in profile
	public void CheckDataProvided() throws IOException {



		MyProfile profile=new MyProfile(driver);
		profile.getProfile().click();
		profile.getCreateProfile().click();


		CreateProfileObjects cp=new CreateProfileObjects(driver);
		Assert.assertTrue(cp.getName().isDisplayed());
		
		Assert.assertTrue(cp.getEmail().isDisplayed());
		Assert.assertTrue(cp.getPhone().isDisplayed());



	}

	@Test(priority=3) 
	public void Filldetails() throws InterruptedException, IOException {

		

	
		//String dob=ExcelUtility.getCellData(2, 1);
		String gender=ExcelUtility.getStringCellData(3, 1);
		
		String email=ExcelUtility.getStringCellData(4, 1);
		
		System.out.println(email);
		//double mob=ExcelUtility.getNumericCellData(5, 1);
		String HighSchoolBoard=ExcelUtility.getStringCellData(6, 1);
		double Percent=ExcelUtility.getNumericCellData(7, 1);
		String HighSchoolPercent=String.valueOf(Percent);
		String HighSchoolName=ExcelUtility.getStringCellData(8, 1);
	
		double Year =ExcelUtility.getNumericCellData(9, 1);
		String HighSchoolYear=String.valueOf(Year);
		
		String HigherSchoolBoard=ExcelUtility.getStringCellData(10, 1);
		double HigherPercent=ExcelUtility.getNumericCellData(11, 1);
		String HigherSchoolPercent=String.valueOf(Percent);
		String HigherSchoolName=ExcelUtility.getStringCellData(12, 1);
	
		double HigherYear =ExcelUtility.getNumericCellData(13, 1);
		String HigherSchoolYear=String.valueOf(Year);
		
		String skill=ExcelUtility.getStringCellData(14, 1);
	
		String Language=ExcelUtility.getStringCellData(15, 1);
		
		//String Description=ExcelUtility.getStringCellData(16, 1);
		
		MyProfile profile=new MyProfile(driver);
		profile.getProfile().click();
		profile.getCreateProfile().click();
		
		CreateProfileObjects cp=new CreateProfileObjects(driver);
		cp.getDtae().sendKeys("1998-08-13");
		cp.selectFemale().click();
		
		cp.selectHighSchoolBoard().sendKeys(HighSchoolBoard);
		cp.selectHighSchoolPercentage().sendKeys(HighSchoolPercent);
		//String.valueOf(HighSchoolPercent)
		//Double.toString(HighSchoolPercent)
		cp.selectHighSchoolName().sendKeys(HighSchoolName);
		cp.selectHighSchoolYear().sendKeys(HighSchoolYear);

		JavascriptExecutor Js1 = (JavascriptExecutor) driver;
		Js1.executeScript("window.scrollBy(0,300)");    
		Thread.sleep(3000);
		Select HighersecondaryBoard= new Select(cp.getHigherSecondaryBoard());
		HighersecondaryBoard.selectByVisibleText(HigherSchoolBoard);
		cp.getHigherSecondaryPercentage().sendKeys(HigherSchoolPercent);
		cp.getHigherSecondarySchool().sendKeys(HigherSchoolName);
		cp.getHigherSecondaryYear().sendKeys(HigherSchoolYear);

		//JavascriptExecutor Js1 = (JavascriptExecutor) driver;
		Js1.executeScript("window.scrollBy(0,1400)"); 
		//scroll 1000 pixel vertical
		Thread.sleep(3000);

		cp.getAddSkillButton().click();
		cp.getSkillField().sendKeys(skill);
		cp.getAddLanguageButton().click();
		cp.getLanguageField().sendKeys(Language);
		cp.getDescription().sendKeys("fffffffffffffffffffffffffffffff");
		Js1.executeScript("window.scrollBy(0,200)");                   //scroll 1000 pixel vertical
		
		
		Thread.sleep(3000);
		 //FileInputStream ExcelFile = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources"
         //        + "/data6.xlsx");
		cp.selectImage().sendKeys("C:\\Users\\athira anilkumar\\eclipse project\\DigitalResume2\\images\\user.jpg");
		//String loc=System.getProperty("user.dir") +"images\" +"\'user.jpg";
		//cp.selectImage().sendKeys(loc);
		cp.getCheckbox().click();
		
		cp.getSubmit().click();
		Assert.assertEquals(driver.switchTo().alert().getText(), "Profile created");
		driver.switchTo().alert().accept();

		//LoginPage lp=new LoginPage(driver);
		//lp.getlogout();
 

	}
	
	


}



