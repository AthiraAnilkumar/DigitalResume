package com.drb.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.drb.utilities.ExcelUtility;

public class test {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		WebDriver driver;
		//System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/driver" +"/chromedriver.exe");
		 //driver =new ChromeDriver();
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/driver" +"/geckodriver.exe");
		driver =new FirefoxDriver();
		//String url=prop.getProperty("url");
		//driver.get(url);
		
		 //driver.get("http://167.71.226.96/login");
		 driver.get("http://167.71.226.96/login");
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		 double HighSchoolPercent=ExcelUtility.getNumericCellData(7, 1);
		 System.out.println(HighSchoolPercent);
		 
	}

}
