package com.drb.scripts;

import java.io.File;
import org.apache.commons.io.FileUtils;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
	public static WebDriver driver;
	public Properties prop;


	public WebDriver initinalizeDriver() throws IOException {
		prop=new Properties();
		FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"/src/main/java/com/drb/constants" +"/data.properties");		
		prop.load(fis);
		String browserName= prop.getProperty("browser");
		if(browserName.equals("chrome")) {

			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/driver" +"/chromedriver.exe" );
			driver =new ChromeDriver();
			String url=prop.getProperty("url");
			driver.get(url);
		}
		else if(browserName.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/driver" +"/geckodriver.exe");
			driver =new FirefoxDriver();
			String url=prop.getProperty("url");
			driver.get(url);

		}
		driver.manage().window().maximize();   
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		return driver;
	}


	public void getScreenShotPath(String testCaseName) throws IOException {

		TakesScreenshot ts=(TakesScreenshot) driver;
		File source=ts.getScreenshotAs(OutputType.FILE);

		String destinationFile=System.getProperty("user.dir")+"\\reports\\"+testCaseName+".png";
		FileUtils.copyFile(source,new File(destinationFile));


	}


}
