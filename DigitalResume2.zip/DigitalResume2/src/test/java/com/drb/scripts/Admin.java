package com.drb.scripts;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.drb.pages.AdminObjects;
import com.drb.pages.LoginPage;

@Listeners(CustomListeners.class)
public class Admin extends TestBase {

	public WebDriver driver;


	@Test
	public void adminNotification() throws IOException, InterruptedException {
		driver=initinalizeDriver();
		//admin Login
		
		//CreateProfile profile= new CreateProfile(driver);
		//profile.Login();
		//profile.Filldetails();
		
		
		JavascriptExecutor Js1 = (JavascriptExecutor) driver;
		Js1.executeScript("window.scrollBy(0,-2200)"); 
		Thread.sleep(3000);
		driver=initinalizeDriver();
		LoginPage login=new LoginPage(driver);
		login.clickSignup().click();
		login.getUsername().sendKeys("admin");
		login.getPassword().sendKeys("Admin12345");
		login.getCheckbox().click();
		login.getLoginButton().click();

		AdminObjects admin=new AdminObjects(driver);
		admin.clickNotification().click();

		List<WebElement> NotficatiomList=admin.getNotificationList();
		System.out.println(NotficatiomList.size());
		int Listsize=NotficatiomList.size();
		for(int i=0;i<Listsize;i++) {
			String Entry=NotficatiomList.get(i).getText();
			if(Entry.contains("User Created a profile")) {


				String[] ProfileNot=NotficatiomList.get(i).getText().split("User");
				String Name=ProfileNot[0];

				//System.out.println(Name);
				if(Name.equalsIgnoreCase("Athira")) {
					Assert.assertEquals(Name, "Athira");

					/*
						JavascriptExecutor Js1 = (JavascriptExecutor) driver;
						Js1.executeScript("window.scrollBy(0,1700)"); 
						Thread.sleep(3000);
						NotficatiomList.get(i).click();
						System.out.println("just found");
					 */
					break;
				}

			}
			//
			//	

		}

	}


}
