package com.drb.scripts;

import java.io.IOException;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Listeners;

import com.drb.pages.CreateProfileObjects;
import com.drb.pages.LoginPage;
import com.drb.pages.MyProfile;

@Listeners(CustomListeners.class)
public class HomePage extends TestBase {

	public WebDriver driver;
	@BeforeTest
	public void browserInvoke() throws IOException {
		driver=initinalizeDriver();
		//String url=prop.getProperty("url");
		//driver.get(url);
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);

	}

	@Test(priority=1)
	public void OpenBrowser() throws IOException {



		LoginPage login=new LoginPage(driver);
		login.clickSignup().click();
		login.getUsername().sendKeys("Athira");
		login.getPassword().sendKeys("Password@123");
		login.getCheckbox().click();
		login.getLoginButton().click();
		System.out.println("OpenBrowser");
	}


	

	@Test(priority=2)
	public void goMyprofile() {
		System.out.println("goMyprofile");	
		//A user having a profile clicks on My Profile Button,
		MyProfile profile=new MyProfile(driver);
		profile.getProfile().click();
		//Assert.assertTrue(profile.getImage().isDisplayed());
		boolean DelProf=profile.getDeleteProfile().isDisplayed();
		boolean EditProf=profile.getEditProfile().isDisplayed();
		//System.out.println(DelProf);
		Assert.assertTrue(DelProf);
		Assert.assertTrue(EditProf);
		//boolean Image=profile.getImage().isDisplayed();
		//System.out.println(Image);

	}
	@Test(priority=3)
	public void cancelDeleteProfile() {
		//User Cancel delete profile &
		MyProfile profile=new MyProfile(driver);
		profile.getProfile().click();
		profile.getDeleteProfile().click();
		System.out.println("deleteProfile");
		//System.out.println(driver.switchTo().alert().getText());
		Assert.assertEquals(driver.switchTo().alert().getText(),"Are you sure ,you want to delete your profile?");
		//driver.switchTo().alert().accept();
		driver.switchTo().alert().dismiss();
		
	}
	@Test(priority=4)
	public void confirmDeleteProfile() {
		//User Cancel delete profile &
		MyProfile profile=new MyProfile(driver);
		profile.getProfile().click();
		profile.getDeleteProfile().click();
		System.out.println("deleteProfile");
		//System.out.println(driver.switchTo().alert().getText());
		Assert.assertEquals(driver.switchTo().alert().getText(),"Are you sure ,you want to delete your profile?");
		//driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		Assert.assertEquals(profile.getCreateProfile().getAttribute("innerText"),"Create a Profile Now");
		
		
	}
	


	/*@AfterTest
	public void tearDown() {
		driver.close();
	}
	 */
}
