package com.drb.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	public WebDriver driver;

	By signup=By.cssSelector("a[href='/login']");
	By username=By.cssSelector("input[name='Username']");
	By password=By.cssSelector("input[name='pass']");
	By rememberMe=By.className("label-checkbox100");
	
	By loginbutton=By.xpath("//button[text()=' Login ']");
	//By logout=By.cssSelector("a[href='/login']");
	

	public LoginPage(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		this.driver=driver2;
	}

	public WebElement clickSignup() {

		return driver.findElement(signup);
	}

	public WebElement getUsername() {
		return driver.findElement(username);

	}
	
	public WebElement getPassword() {
		return driver.findElement(password);
	}

 public WebElement getCheckbox() {
	 return driver.findElement(rememberMe);
 }
 
 public WebElement getLoginButton() {
	 return driver.findElement(loginbutton);
 }
 
 //public WebElement getlogout() {
//	 return driver.findElement(logout);
 //}
}
