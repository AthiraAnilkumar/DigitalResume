
package com.drb.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MyProfile {
	
	public WebDriver driver;
	By profile=By.cssSelector("a[href='/profilehome']");
	By image=By.cssSelector("img[alt='img']");
	By ProfileName=By.cssSelector("div.h2.title");
	By EditProfile=By.cssSelector("a[href='/editform']");
	By DeleteProfile=By.xpath("//a[text()='Delete Profile']");
	By CreateProfile=By.xpath("//button[text()='Create a Profile Now']");
	
	
	
	public MyProfile(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		this.driver=driver2;
	}


	public WebElement getProfile() {
		
	//return	driver.findElement(profile);
	return driver.findElement(profile);
	}
	
	public WebElement getImage() {
		
		return driver.findElement(image);
	}
   public WebElement getName() {
	    return driver.findElement(ProfileName);
   }
   
   public WebElement getEditProfile() {
	   return driver.findElement(EditProfile);
   }
   public WebElement getDeleteProfile() {
	   
	   return driver.findElement(DeleteProfile);
   }
   public WebElement getCreateProfile() {
	   //return driver.findElement(CreateProfile).getText();
	   System.out.println("iam in my profile");
	   return driver.findElement(CreateProfile);
	   
   }
}
