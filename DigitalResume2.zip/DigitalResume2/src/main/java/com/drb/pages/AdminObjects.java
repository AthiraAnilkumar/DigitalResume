package com.drb.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AdminObjects {
	public WebDriver driver;
	By Notification=By.cssSelector("a[href='/notification']");
	By NotList=By.xpath("//table//tr");
	By NotProfile=By.xpath("//table//tr//td//a[@href='/userlist']");
	
	public AdminObjects(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		this.driver=driver2;
	}
	public WebElement clickNotification() {
		return driver.findElement(Notification);
	}
	
	public List<WebElement> getNotificationList() {
		
		return	driver.findElements(NotList);
	
	}
	
	public WebElement getSelectedNotification() {
		return driver.findElement(NotProfile);
	}

}

