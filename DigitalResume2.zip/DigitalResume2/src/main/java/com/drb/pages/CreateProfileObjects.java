package com.drb.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class CreateProfileObjects {

	public WebDriver driver;
	By name=By.id("name");
	By dateofbirth=By.id("date");
	By email=By.id("email_id");
	By phone=By.id("phone");
	By male=By.cssSelector("input[value='male']");
	By female=By.cssSelector("input[value='female']");

	By highSchoolBoard=By.xpath("//p[@formgroupname='highschools']//select[@formcontrolname='edu_title']");
	By highSchoolPercentage=By.xpath("//p[@formgroupname='highschools']//input[@placeholder='Percentage Scored']");
	By highSchoolName=By.xpath("//p[@formgroupname='highschools']//input[@placeholder='School Name']");
	By highSchoolYear=By.xpath("//p[@formgroupname='highschools']//input[@placeholder='Year of Pass']");

	By higherSecondaryBoard=By.xpath("//p[@formgroupname='higherschools']//select");
	By higherSecondaryPercentage=By.xpath("//p[@formgroupname='higherschools']//input[@placeholder='Percentage Scored']");
	By higherSchoolName=By.xpath("//p[@formgroupname='higherschools']//input[@placeholder='School Name']");
	By higherSchoolYear=By.xpath("//p[@formgroupname='higherschools']//input[@placeholder='Year of Pass']");

	//select highSchoolBoard=
	//table[@class='table table-bordered ng-dirty ng-touched ng-invalid']//button[@type='button'][normalize-space()='Add']
	By addProjectButton=By.xpath("//table[@formarrayname='projects']//tr//th[2]//button");
	By addSkillsButton=By.xpath("//table[@formarrayname='skills']//tr//th[2]//button");
	By skillField=By.cssSelector("input[formcontrolname='skills']");
	By addLanguageButton=By.xpath("//table[@formarrayname='languages']//tr//th[2]//button");
	By languageField=By.xpath("//input[@formcontrolname='languages']");
	
	

	By description=By.cssSelector("textarea#yourself");
	By image=By.xpath("//input[@name='image']");
	By checkbox=By.cssSelector("input[type='checkbox']");
	By submitButton=By.cssSelector("button.btn.btn-success");




	public CreateProfileObjects(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		this.driver=driver2;
	}

	public WebElement getName() {
		return	driver.findElement(name);
	}

	public WebElement getEmail() {
		return	driver.findElement(email);
	}
	public WebElement getPhone() {
		return	driver.findElement(phone);
	}
	public WebElement getDtae() {
		return driver.findElement(dateofbirth);
	}
	public WebElement selectMale() {
		return driver.findElement(male);
	}
	public WebElement selectFemale() {
		return driver.findElement(female);
	}


	public WebElement selectHighSchoolBoard() {
		return driver.findElement(highSchoolBoard);

	}

	public WebElement selectHighSchoolPercentage() {
		return driver.findElement(highSchoolPercentage);

	}
	public WebElement selectHighSchoolName() {
		return driver.findElement(highSchoolName);
	}

	public WebElement selectHighSchoolYear() {
		return driver.findElement(highSchoolYear);
	}

	

	public WebElement getHigherSecondaryBoard() {
		return driver.findElement(higherSecondaryBoard);
	}
	public WebElement getHigherSecondaryPercentage() {
		return driver.findElement(higherSecondaryPercentage);
	}
	public WebElement getHigherSecondarySchool() {
		return driver.findElement(higherSchoolName);
	}
	public WebElement getHigherSecondaryYear() {
		return driver.findElement(higherSchoolYear);
	}




	public WebElement getAddSkillButton() {
		return driver.findElement(addSkillsButton);
	}
	public WebElement getSkillField() {
		return driver.findElement(skillField);
	}

	public WebElement getAddLanguageButton() {
		return driver.findElement(addLanguageButton);
	}
	public WebElement getLanguageField() {
		return driver.findElement(languageField);
	}
	
	public WebElement getDescription() {
		return driver.findElement(description);
	}
	
	public WebElement selectImage() {
		return driver.findElement(image);
	}
	
	public WebElement getCheckbox() {
		return driver.findElement(checkbox);
	}
	public WebElement getSubmit() {
		return driver.findElement(submitButton);
	}
	
	
	public void getAddProjectButton() throws InterruptedException {
		WebElement addbutton=driver.findElement(addProjectButton);
		//Actions action = new Actions(driver);
		//action.moveToElement(addbutton);
		JavascriptExecutor Js1 = (JavascriptExecutor) driver;
		Js1.executeScript("window.scrollBy(0,1000)");                   //scroll 1000 pixel vertical
		Thread.sleep(3000);
		System.out.println("helllo" + addbutton.isDisplayed());
		addbutton.click();

		//return driver.findElement(addProjectButton);

	}


}

